define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./django.snippets");
exports.scope = "django";

});
