define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./csharp.snippets");
exports.scope = "csharp";

});
