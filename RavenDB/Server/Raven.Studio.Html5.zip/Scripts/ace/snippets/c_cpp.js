define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./c_cpp.snippets");
exports.scope = "c_cpp";

});
