define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./clojure.snippets");
exports.scope = "clojure";

});
