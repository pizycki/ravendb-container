define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./assembly_x86.snippets");
exports.scope = "assembly_x86";

});
